export default {
    stage0: {
        yFrame: 0,
        frames: 2
    },
    stage1: {
        yFrame: 1,
        frames: 2
    },
    stage2: {
        yFrame: 2,
        frames: 10
    }
};
