export default {
    default: {
        yFrame: 0,
        frames: 2
    }
};
