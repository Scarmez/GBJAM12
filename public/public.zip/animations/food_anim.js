export default {
    eyeball: {
        yFrame: 0,
        frames: 4
    },
    onigiri: {
        yFrame: 1,
        frames: 4
    },
    toffee_apple: {
        yFrame: 2,
        frames: 4
    },
    crunchy_bug: {
        yFrame: 3,
        frames: 4
    },
};
