export default {
    feed: {
        yFrame: 0,
        frames: 2
    },
    play: {
        yFrame: 0,
        frames: 2
    }
};
