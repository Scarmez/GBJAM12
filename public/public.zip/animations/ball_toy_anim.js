export default {
    bubble: {
        yFrame: 0,
        frames: 3
    }
};
