export default {
    question: {
        yFrame: 0,
        frames: 2
    },
    happy: {
        yFrame: 1,
        frames: 2
    },
    sad: {
        yFrame: 2,
        frames: 2
    },
    love: {
        yFrame: 3,
        frames: 2
    },
    exclaim: {
        yFrame: 4,
        frames: 2
    },
    hungry: {
        yFrame: 5,
        frames: 2
    },
    bored: {
        yFrame: 6,
        frames: 2
    },
    frustrated: {
        yFrame: 7,
        frames: 2
    },
};
