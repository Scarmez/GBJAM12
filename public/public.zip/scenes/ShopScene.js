import { Scene } from "../engine/Scene";
export class ShopScene extends Scene {
    create() { }
}
