export default {
    width: 5,
    height: 1,
    pixels: [
        0, 1, 2, 3, 4
    ]
};
